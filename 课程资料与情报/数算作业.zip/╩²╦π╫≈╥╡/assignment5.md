# Assignment #5: "树"算：概念、表示、解析、遍历

Updated 2124 GMT+8 March 17, 2024

2024 spring, Complied by ==同学的姓名、院系==



**说明：**

1）The complete process to learn DSA from scratch can be broken into 4 parts:

Learn about Time complexities, learn the basics of individual Data Structures, learn the basics of Algorithms, and practice Problems.

2）请把每个题目解题思路（可选），源码Python, 或者C++（已经在Codeforces/Openjudge上AC），截图（包含Accepted），填写到下面作业模版中（推荐使用 typora https://typoraio.cn ，或者用word）。AC 或者没有AC，都请标上每个题目大致花费时间。

3）提交时候先提交pdf文件，再把md或者doc文件上传到右侧“作业评论”。Canvas需要有同学清晰头像、提交文件有pdf、"作业评论"区有上传的md或者doc附件。

4）如果不能在截止前提交作业，请写明原因。



**编程环境**

==（请改为同学的操作系统、编程环境等）==

操作系统：macOS Ventura 13.4.1 (c)

Python编程环境：Spyder IDE 5.2.2, PyCharm 2023.1.4 (Professional Edition)

C/C++编程环境：Mac terminal vi (version 9.0.1424), g++/gcc (Apple clang version 14.0.3, clang-1403.0.22.14.1)



## 1. 题目

### 27638: 求二叉树的高度和叶子数目

http://cs101.openjudge.cn/practice/27638/



思路：
在上次的代码上加一些修改


代码

```python
# 
s=[]
ans=0
leave=0
def search(cnt,cur):
    global ans
    global leave
    if s[cur][1]==-1 and s[cur][2] ==-1:
        if cnt>ans:
            ans=cnt
        return
    else:
        if s[cur][1]!=-1:
            search(cnt+1,s[cur][1])
        if s[cur][2]!=-1:
            search(cnt+1,s[cur][2])
n=int(input())
for i in range(n):
    x,y=map(int,input().split())
    s.append((i,x,y))
for i in range(n):
    search(0,i)
for i in range(n):
    if s[i][1]==-1 and s[i][2] ==-1:
        leave+=1
print(ans,end=" ")
print(leave)
```



代码运行截图 ==（至少包含有"Accepted"）==
[![pFhexNq.png](https://s21.ax1x.com/2024/03/22/pFhexNq.png)](https://imgse.com/i/pFhexNq)




### 24729: 括号嵌套树

http://cs101.openjudge.cn/practice/24729/



思路：
最大的难点是这道题不是二叉树，自己调的tree_node总是出问题没法正确遍历，而且多个括号平行排列的时候如何识别也是个挑战，最后没调好看了题解


代码

```python
# 

```



代码运行截图 ==（至少包含有"Accepted"）==





### 02775: 文件结构“图”

http://cs101.openjudge.cn/practice/02775/



思路：
一开始打算用列表套列表一层层套做，但是这样相当的麻烦而且不方便输出和多组数据识别，花了很长时间，最后看了题解理解了正确的思路


代码

```python
# 

```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==





### 25140: 根据后序表达式建立队列表达式

http://cs101.openjudge.cn/practice/25140/



思路：
逐层遍历确实对我是个新东西，我觉得它比剩下三种遍历要更难实现


代码

```python
# 
class Node:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None

def postorder_to_inorder(postorder):
    stack = []
    for char in postorder:
        if char.islower():
            stack.append(Node(char))
        else:
            right = stack.pop()
            left = stack.pop()
            node = Node(char)
            node.left = left
            node.right = right
            stack.append(node)
    root = stack.pop()
    return root

def level_order_traversal_reverse(root):
    queue = [root]
    result = []
    while queue:
        node = queue.pop(0)
        if node:
            result.append(node.value)
            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)
    return ''.join(result[::-1])

n = int(input())
expressions = []
for _ in range(n):
    expression = input()
    expressions.append(expression)

for exp in expressions:
    root = postorder_to_inorder(exp)
    queue_expression = level_order_traversal_reverse(root)
    print(queue_expression)

```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==
[![pF43mMq.png](https://s21.ax1x.com/2024/03/24/pF43mMq.png)](https://imgse.com/i/pF43mMq)
### 24750: 根据二叉树中后序序列建树

http://cs101.openjudge.cn/practice/24750/

代码

```python
# 
class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def build_tree(inorder, postorder):
    if not inorder:
        return []
    root_val = postorder.pop()
    root = TreeNode(root_val)
    root_idx = inorder.index(root_val)
    root.right = build_tree(inorder[root_idx + 1:], postorder)
    root.left = build_tree(inorder[:root_idx], postorder) 
    return root

def inorder_traversal(root, result):
    if not root:
        return
    result.append(root.val)
    inorder_traversal(root.left, result)
    inorder_traversal(root.right, result)


x=input()
y=input()
inorder=[]
postorder=[]
for i in range(0,len(x)):
    inorder.append(x[i])
for i in range(0,len(y)):
    postorder.append(y[i])
root = build_tree(inorder, postorder)
preorder_result = []
inorder_traversal(root, preorder_result)
for i in range(0,len(preorder_result)):
    print(preorder_result[i],end="")
```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==
[![pFhtdk8.png](https://s21.ax1x.com/2024/03/23/pFhtdk8.png)](https://imgse.com/i/pFhtdk8)

### 22158: 根据二叉树前中序序列建树

http://cs101.openjudge.cn/practice/22158/



思路：
基本和上一道相同
代码

```python
# 
class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def build_tree(preorder, inorder):
    if not inorder:
        return None
    root_val = preorder.pop(0)
    root = TreeNode(root_val)
    root_idx = inorder.index(root_val)
    root.left = build_tree(preorder, inorder[:root_idx])
    root.right = build_tree(preorder, inorder[root_idx + 1:])
    return root

def postorder_traversal(root, result):
    if not root:
        return
    postorder_traversal(root.left, result)
    postorder_traversal(root.right, result)
    result.append(root.val)

while True:
    try:
        x = input()
        y = input()
        preorder = [char for char in x]
        inorder = [char for char in y]
        root = build_tree(preorder, inorder)
        postorder_result = []
        postorder_traversal(root, postorder_result)
        for char in postorder_result:
            print(char, end="")
        print()
    except EOFError:
        break
```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==
[![pF43loF.png](https://s21.ax1x.com/2024/03/24/pF43loF.png)](https://imgse.com/i/pF43loF)
## 2. 学习总结和收获
树的计算和递归是离不开的，我目前能理解和处理较简单的二叉树，但对于更复杂的树仍然应当多加思考和联系
==如果作业题目简单，有否额外练习题目，比如：OJ“2024spring每日选做”、CF、LeetCode、洛谷等网站题目。==





