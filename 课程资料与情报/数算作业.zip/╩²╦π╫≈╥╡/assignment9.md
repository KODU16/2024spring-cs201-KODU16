# Assignment #9: 图论：遍历，及 树算

Updated 1739 GMT+8 Apr 14, 2024

2024 spring, Complied by ==同学的姓名、院系==



**说明：**

1）请把每个题目解题思路（可选），源码Python, 或者C++（已经在Codeforces/Openjudge上AC），截图（包含Accepted），填写到下面作业模版中（推荐使用 typora https://typoraio.cn ，或者用word）。AC 或者没有AC，都请标上每个题目大致花费时间。

2）提交时候先提交pdf文件，再把md或者doc文件上传到右侧“作业评论”。Canvas需要有同学清晰头像、提交文件有pdf、"作业评论"区有上传的md或者doc附件。

3）如果不能在截止前提交作业，请写明原因。

## 1. 题目

### 04081: 树的转换

http://cs101.openjudge.cn/dsapre/04081/



思路：
看起来是个递归，但是写下来还是个考验...


代码

```python
# 
class TreeNode:
    def __init__(self, val):
        self.val = val
        self.left = None  # 左儿子
        self.right = None  # 右兄弟


def convert_tree(input_str):
    def dfs(input_str, index):
        if index >= len(input_str):
            return None, index
        if input_str[index] == 'u':
            return None, index + 1
        root = TreeNode(index)
        root.left, index = dfs(input_str, index + 1)
        root.right, index = dfs(input_str, index)
        return root, index

    root, _ = dfs(input_str, 0)

    def height(root):
        if not root:
            return 0
        return max(height(root.left) + 1, height(root.right))

    return root, height(root)


input_str = input()

root, original_height = convert_tree(input_str)


def calculate_binary_tree_height(root):
    if not root:
        return 0
    left_height = calculate_binary_tree_height(root.left)
    right_height = calculate_binary_tree_height(root.right)
    return max(left_height, right_height) + 1


binary_tree_height = calculate_binary_tree_height(root)

print(original_height,end=" => ")
print(binary_tree_height)
```



代码运行截图 ==（至少包含有"Accepted"）==
[![pkpqLDK.png](https://s21.ax1x.com/2024/04/22/pkpqLDK.png)](https://imgse.com/i/pkpqLDK)




### 08581: 扩展二叉树

http://cs101.openjudge.cn/dsapre/08581/



思路：需要用到栈
我感觉我不一定能限时独立完成这玩意



代码

```python
# 
class TreeNode:
    def __init__(self, val):
        self.val = val
        self.left = None
        self.right = None

def construct_tree(preorder):
    if not preorder:
        return None

    def helper(i):
        if i >= len(preorder) or preorder[i] == '.':
            return None, i + 1

        node = TreeNode(preorder[i])
        left, i = helper(i + 1)
        right, i = helper(i)
        node.left = left
        node.right = right
        return node, i

    root, _ = helper(0)
    return root

def inorder_traversal(root):
    if not root:
        return []
    return inorder_traversal(root.left) + [root.val] + inorder_traversal(root.right)

def postorder_traversal(root):
    if not root:
        return []
    return postorder_traversal(root.left) + postorder_traversal(root.right) + [root.val]

preorder = input()
root = construct_tree(preorder)
inorder = inorder_traversal(root)
postorder = postorder_traversal(root)
print(''.join(inorder))
print(''.join(postorder))

```



代码运行截图 ==（至少包含有"Accepted"）==
[![pkpOpoF.png](https://s21.ax1x.com/2024/04/22/pkpOpoF.png)](https://imgse.com/i/pkpOpoF)




### 22067: 快速堆猪

http://cs101.openjudge.cn/practice/22067/



思路：
是一个堆的题目，有很多非法操作还是需要特判
不知道为啥我的程序不能正确更新最小值

代码

```python
# 
import heapq

class MinHeapWithPop:
    def __init__(self):
        self.heap = []
        self.min_value = float('inf')

    def push(self, val):
        heapq.heappush(self.heap, val)
        self.min_value = min(self.min_value, val)

    def pop(self):
        if not self.heap:
            return -1
        popped = heapq.heappop(self.heap)
        if popped == self.min_value:
            self.update_min_value()  # 在弹出元素后更新最小值
        return 1

    def update_min_value(self):
        self.min_value = min(self.heap) if self.heap else float('inf')

    def peek_min(self):
        if not self.heap:
            return -1
        return self.min_value

heap = MinHeapWithPop()
while True:
    try:
        line=input()
        l = line.split()
        if l[0] == 'push':
            heap.push(int(l[1]))
        elif l[0] == 'pop':
            heap.pop()
        elif l[0] == 'min':
            i = heap.peek_min()
            if i != -1:
                print(i)
    except EOFError:
        break
```

### 04123: 马走日

dfs, http://cs101.openjudge.cn/practice/04123



思路：
是深度优先搜索，但是我的程序一直没法正确判断是否已经访问过，我可能需要再想想


代码

```python
# 
n = 0
m = 0
movex = [1, 2, 2, 1, -1, -2, -2, -1]
movey = [2, 1, -1, -2, -2, -1, 1, 2]

def dfs(x, y, visited):
    global n, m
    if x < 0 or x >= n or y < 0 or y >= m or visited[x][y]:
        return 0
    if x == n - 1 and y == m - 1:
        return 1
    visited[x][y] = True
    cur = 0
    for i in range(8):
        cur += dfs(x + movex[i], y + movey[i], visited)
    visited[x][y] = False  # 在计算 cur 之前将其标记为 False
    return cur

t = int(input())
for _ in range(t):
    n, m, x, y = map(int, input().split())
    visited = [[False] * m for _ in range(n)]
    print(dfs(x, y, visited))

```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==





### 28046: 词梯

bfs, http://cs101.openjudge.cn/practice/28046/

虽然是bfs但是结构非常复杂（之前还以为自己完全会了bfs呢）
还是看了题解



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==





### 28050: 骑士周游

dfs, http://cs101.openjudge.cn/practice/28050/

这题和马走日很像，看了题解后大概了解此类题要采用何种思路了


## 2. 学习总结和收获

==如果作业题目简单，有否额外练习题目，比如：OJ“2024spring每日选做”、CF、LeetCode、洛谷等网站题目。==
这周的题相当的难，希望考试不要考这样难的题目
不过还是能从中学到很多东西，比如我现在是已经能写出bfs和dfs了，遍历树也基本熟练。


