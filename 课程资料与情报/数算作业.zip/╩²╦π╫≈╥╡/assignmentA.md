# Assignment #A: 图论：算法，树算及栈

Updated 2018 GMT+8 Apr 21, 2024

2024 spring, Complied by ==同学的姓名、院系==



**说明：**

1）请把每个题目解题思路（可选），源码Python, 或者C++（已经在Codeforces/Openjudge上AC），截图（包含Accepted），填写到下面作业模版中（推荐使用 typora https://typoraio.cn ，或者用word）。AC 或者没有AC，都请标上每个题目大致花费时间。

2）提交时候先提交pdf文件，再把md或者doc文件上传到右侧“作业评论”。Canvas需要有同学清晰头像、提交文件有pdf、"作业评论"区有上传的md或者doc附件。

3）如果不能在截止前提交作业，请写明原因。


## 1. 题目

### 20743: 整人的提词本

http://cs101.openjudge.cn/practice/20743/



思路：
我让gpt帮我修了修函数部分，主要是我没掌握那种简洁的写法


代码

```python
# 
def reverse_brackets(script):
    stack = []
    script = list(script)
    
    for i in range(len(script)):
        if script[i] == '(':
            stack.append(i)
        elif script[i] == ')':
            left = stack.pop()
            right = i
            while left < right:
                script[left], script[right] = script[right], script[left]
                left += 1
                right -= 1
    
    result = ''.join([char for char in script if char not in '()'])
    return result

script = input()
result = reverse_brackets(script)
print(result)
```



代码运行截图 ==（至少包含有"Accepted"）==
[![pkFgtOg.png](https://s21.ax1x.com/2024/04/30/pkFgtOg.png)](https://imgse.com/i/pkFgtOg)




### 02255: 重建二叉树

http://cs101.openjudge.cn/practice/02255/



思路：
其实这就是之前那道题


代码

```python
# 
class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def build_tree(preorder, inorder):
    if not inorder:
        return None
    root_val = preorder.pop(0)
    root = TreeNode(root_val)
    root_idx = inorder.index(root_val)
    root.left = build_tree(preorder, inorder[:root_idx])
    root.right = build_tree(preorder, inorder[root_idx + 1:])
    return root

def postorder_traversal(root, result):
    if not root:
        return
    postorder_traversal(root.left, result)
    postorder_traversal(root.right, result)
    result.append(root.val)

while True:
    try:
        x,y= input().split()
        preorder = [char for char in x]
        inorder = [char for char in y]
        root = build_tree(preorder, inorder)
        postorder_result = []
        postorder_traversal(root, postorder_result)
        for char in postorder_result:
            print(char, end="")
        print()
    except EOFError:
        break
```



代码运行截图 ==（至少包含有"Accepted"）==
[![pkFgBYq.png](https://s21.ax1x.com/2024/04/30/pkFgBYq.png)](https://imgse.com/i/pkFgBYq)




### 01426: Find The Multiple

http://cs101.openjudge.cn/practice/01426/

要求用bfs实现



思路：
我一开始还以为都得找那个长的...


代码

```python
# 
from collections import deque

def find_multiple_of_01(number):
    if number == 0:
        return "0"

    queue = deque(["1"])

    while queue:
        current = queue.popleft()
        if int(current) % number == 0:
            return current
        queue.append(current + "0")
        queue.append(current + "1")

while True:
    number = int(input())
    if number==0:
        break
    result = find_multiple_of_01(number)
    print(result)

```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==
[![pkFRain.png](https://s21.ax1x.com/2024/04/30/pkFRain.png)](https://imgse.com/i/pkFRain)




### 04115: 鸣人和佐助

bfs, http://cs101.openjudge.cn/practice/04115/
超时了，感觉很多人都和我犯了一样的错误，看看题解
代码

```python
# 
m, n, ckl = map(int, input().split())
map_grid = []
time = float('inf')
movex = [1, 0, 0, -1]
movey = [0, 1, -1, 0]

def bfs(x, y, ckl, t):
    global time
    if x < 0 or x >= m or y < 0 or y >= n or ckl < 0 or t >= time or map_grid[x][y] == 'x':
        return
    if map_grid[x][y] == '+':
        time = min(time, t)
        return
    if map_grid[x][y] == '#':
        ckl -= 1
    memo=map_grid[x][y]
    map_grid[x][y] = 'x'
    for i in range(4):
        bfs(x + movex[i], y + movey[i], ckl, t + 1)
    map_grid[x][y] = memo
    return
for i in range(m):
    s = input()
    map_grid.append(list(s))

for i in range(m):
    for j in range(n):
        if map_grid[i][j] == '@':
            mrx = i
            mry = j

bfs(mrx, mry, ckl, 0)

if time != float('inf'):
    print(time)
else:
    print("-1")

```

### 20106: 走山路

Dijkstra, http://cs101.openjudge.cn/practice/20106/



思路：
Dij我能理解，但是我觉得自己的算法有点小问题，看题解了


代码

```python
# 
import heapq

def dijkstra(start, end, heights):
    m, n = len(heights), len(heights[0])
    distances = [[float('inf')] * n for _ in range(m)]
    distances[start[0]][start[1]] = 0
    heap = [(0, start)]
    
    while heap:
        d, (x, y) = heapq.heappop(heap)
        if (x, y) == end:
            return distances[x][y]
        if d > distances[x][y]:
            continue
        for dx, dy in [(1, 0), (-1, 0), (0, 1), (0, -1)]:
            nx, ny = x + dx, y + dy
            if 0 <= nx < m and 0 <= ny < n and heights[nx][ny] != '#':
                nd = max(d, abs(int(heights[nx][ny]) - int(heights[x][y])))
                if nd < distances[nx][ny]:
                    distances[nx][ny] = nd
                    heapq.heappush(heap, (nd, (nx, ny)))
    
    return "NO"

heights=[]
m,n,p=map(int,input().split())
for i in range(m):
    l=list(input().split())
    heights.append(l)
for i in range(p):
    a,b,c,d=map(int,input().split())
    start = (a, b)
    end = (c, d)
    print(dijkstra(start, end, heights))

```

### 05442: 兔子与星空

Prim, http://cs101.openjudge.cn/practice/05442/



思路：
直接看题解了，不过还是学习到了

## 2. 学习总结和收获
直到今天我才真正理解bfs是如何防止不同路径之间访问与否彼此干扰的...
==如果作业题目简单，有否额外练习题目，比如：OJ“2024spring每日选做”、CF、LeetCode、洛谷等网站题目。==





