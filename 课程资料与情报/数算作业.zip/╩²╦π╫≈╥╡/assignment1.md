# Assignment #1: 拉齐大家Python水平

Updated 0940 GMT+8 Feb 19, 2024

2024 spring, Complied by ==同学的姓名、院系==



**说明：**

1）数算课程的先修课是计概，由于计概学习中可能使用了不同的编程语言，而数算课程要求Python语言，因此第一周作业练习Python编程。如果有同学坚持使用C/C++，也可以，但是建议也要会Python语言。

2）请把每个题目解题思路（可选），源码Python, 或者C++（已经在Codeforces/Openjudge上AC），截图（包含Accepted），填写到下面作业模版中（推荐使用 typora https://typoraio.cn ，或者用word）。AC 或者没有AC，都请标上每个题目大致花费时间。

3）课程网站是Canvas平台, https://pku.instructure.com, 学校通知3月1日导入选课名单后启用。**作业写好后，保留在自己手中，待3月1日提交。**

提交时候先提交pdf文件，再把md或者doc文件上传到右侧“作业评论”。Canvas需要有同学清晰头像、提交文件有pdf、"作业评论"区有上传的md或者doc附件。

4）如果不能在截止前提交作业，请写明原因。



**编程环境**

==（请改为同学的操作系统、编程环境等）==

操作系统：macOS Ventura 13.4.1 (c)

Python编程环境：Spyder IDE 5.2.2, PyCharm 2023.1.4 (Professional Edition)

C/C++编程环境：Mac terminal vi (version 9.0.1424), g++/gcc (Apple clang version 14.0.3, clang-1403.0.22.14.1)



## 1. 题目

### 20742: 泰波拿契數

http://cs101.openjudge.cn/practice/20742/
##### 代码

```python
# 
l=[]
l.append(0)
l.append(1)
l.append(1)
n=int(input())
if n>=3:
    for i in range(3,n+1):
        l.append(l[i-1]+l[i-2]+l[i-3])
print(l[n])
```



代码运行截图 ==（至少包含有"Accepted"）==
[![pF0fIxA.png](https://s11.ax1x.com/2024/03/02/pF0fIxA.png)](https://imgse.com/i/pF0fIxA)
### 58A. Chat room

greedy/strings, 1000, http://codeforces.com/problemset/problem/58/A
##### 代码

```python
# 

```



代码运行截图 ==（至少包含有"Accepted"）==
[![pF0hldK.png](https://s11.ax1x.com/2024/03/02/pF0hldK.png)](https://imgse.com/i/pF0hldK)
### 118A. String Task

implementation/strings, 1000, http://codeforces.com/problemset/problem/118/A
##### 代码

```python
# 
s=input()
vowel=['y','a','e','i','o','u']
s=s.lower()
for i in range(0,len(s)):
    pd=0
    for j in range(0,6):
        if s[i]==vowel[j]:
            pd=1
            break
    if pd==0:
        print(".",end="")
        print(s[i],end="")
```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==
[![pFBwQu4.png](https://s11.ax1x.com/2024/03/03/pFBwQu4.png)](https://imgse.com/i/pFBwQu4)
### 22359: Goldbach Conjecture

http://cs101.openjudge.cn/practice/22359/
##### 代码

```python
# 
import math
def iszs(a):
    for i in range(2,int(math.sqrt(a))+1):
        if a%i==0:
            return False
    return True
n=int(input())
for i in range(0,int(n/2)+1):
    if iszs(i) and iszs(n-i):
        print(i,end=" ")
        print(n-i)
        break
```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==
[![pFsaa36.png](https://s21.ax1x.com/2024/03/08/pFsaa36.png)](https://imgse.com/i/pFsaa36)
### 23563: 多项式时间复杂度

http://cs101.openjudge.cn/practice/23563/
##### 代码

```python
# 
n1=input()
s = n1.split("+")
s1=len(s)
ans=1
for i in range(0,s1):
    ans_=0
    if s[i][0]=='0':
        continue
    else:
        j=len(s[i])-1
        m=1
        while s[i][j]!='^':
            ans_+=int(s[i][j])*m
            j-=1
            m*=10
    if ans_>ans:
        ans=ans_
print("n^",end="")
print(ans)
```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==
[![pFsc7O1.png](https://s21.ax1x.com/2024/03/08/pFsc7O1.png)](https://imgse.com/i/pFsc7O1)
### 24684: 直播计票

http://cs101.openjudge.cn/practice/24684/

##### 代码

```python
# 
l = list(map(int, input().split()))
l.sort()
s=len(l)
ans=[]
m=0
cnt=1
for i in range(1,s):
    if l[i]==l[i-1]:
        cnt+=1
    if l[i]!=l[i-1] or i==s-1:
        if cnt>m:
            ans=[]
        if cnt>=m:
            ans.append(l[i-1])
            m=cnt
        cnt=1
out=' '.join(map(str, ans))
print(out)
```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==
[![pFs29CF.png](https://s21.ax1x.com/2024/03/08/pFs29CF.png)](https://imgse.com/i/pFs29CF)
## 2. 学习总结和收获

==如果作业题目简单，有否额外练习题目，比如：OJ“数算pre每日选做”、CF、LeetCode、洛谷等网站题目。==
字符串与数字的转换是重要的方法



