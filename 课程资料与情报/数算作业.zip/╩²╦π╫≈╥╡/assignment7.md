# Assignment #7: April 月考

Updated 1557 GMT+8 Apr 3, 2024

2024 spring, Complied by ==同学的姓名、院系==



**说明：**

1）请把每个题目解题思路（可选），源码Python, 或者C++（已经在Codeforces/Openjudge上AC），截图（包含Accepted），填写到下面作业模版中（推荐使用 typora https://typoraio.cn ，或者用word）。AC 或者没有AC，都请标上每个题目大致花费时间。

2）提交时候先提交pdf文件，再把md或者doc文件上传到右侧“作业评论”。Canvas需要有同学清晰头像、提交文件有pdf、"作业评论"区有上传的md或者doc附件。

3）如果不能在截止前提交作业，请写明原因。

## 1. 题目

### 27706: 逐词倒放

http://cs101.openjudge.cn/practice/27706/



思路：
很简单的倒序遍历，最后一个要处理一下


代码

```python
# 
s=list(input().split())
i=len(s)
for item in reversed(s):
    if i == 1:
        print(item,end="")
    else:
        print(item,end=" ")
    i-=1
```



代码运行截图 ==（至少包含有"Accepted"）==
https://s21.ax1x.com/2024/04/07/pFLAf78.png

### 27951: 机器翻译

http://cs101.openjudge.cn/practice/27951/



思路：
数据再大一些就不能直接模拟了


代码

```python
# 
m,n=map(int,input().split())
cd=[]
ans=0
l=list(input().split())
for i in range(0,n):
    if l[i] in cd:
        continue
    else:
        if len(cd)==m:
            cd.pop(0)
        cd.append(l[i])
        ans+=1
print(ans)
```



代码运行截图 ==（至少包含有"Accepted"）==
[![pFL03NT.png](https://s21.ax1x.com/2024/04/08/pFL03NT.png)](https://imgse.com/i/pFL03NT)




### 27932: Less or Equal

http://cs101.openjudge.cn/practice/27932/
我的程序一直没法处理重复数，GPT也没有给出合适的方案


代码

```python
# 
def partition(arr, low, high):
    pivot = arr[high]
    i = low
    for j in range(low, high):
        if arr[j] < pivot:
            arr[i], arr[j] = arr[j], arr[i]
            i += 1
        elif arr[j] == pivot:
            arr[j], arr[high] = arr[high], arr[j]
    arr[i], arr[high] = arr[high], arr[i]
    return i

def quick_select(arr, low, high, k):
    if low <= high:
        pi = partition(arr, low, high)
        if pi == k:
            return arr[pi]
        elif pi < k:
            return quick_select(arr, pi + 1, high, k)
        else:
            return quick_select(arr, low, pi - 1, k)
    else:
        return -1

n, k = map(int, input().split())
arr = list(map(int, input().split()))
arr = list(set(arr))

if len(arr) < k:
    print(-1)
else:
    result = quick_select(arr, 0, len(arr) - 1, k - 1)
    print(result)

```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==





### 27948: FBI树

http://cs101.openjudge.cn/practice/27948/



思路：
这题看着挺唬人的，实际上简单的很，直接按他说的做就行，我很喜欢做这种题


代码

```python
# 
class TreeNode:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None

def build_FBI_tree(S):
    n = len(S)
    if n == 1:
        if S[0] == '0':
            return TreeNode('B')
        else:
            return TreeNode('I')
    else:
        mid = n // 2
        left_S = S[:mid]
        right_S = S[mid:]
        if '0' in S:
            if '1' in S:
                root_value = 'F'
            else:
                root_value = 'B'
        else:
            root_value = 'I'
        root = TreeNode(root_value)
        root.left = build_FBI_tree(left_S)
        root.right = build_FBI_tree(right_S)
        return root

def postorder_traversal(root):
    if root:
        postorder_traversal(root.left)
        postorder_traversal(root.right)
        print(root.value, end='')

x=input()
S = input()
root = build_FBI_tree(S)
postorder_traversal(root)
```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==
[![pFL2r5R.png](https://s21.ax1x.com/2024/04/08/pFL2r5R.png)](https://imgse.com/i/pFL2r5R)
### 27925: 小组队列

http://cs101.openjudge.cn/practice/27925/



思路：
题目特例非常的多（做题的时候一个宿舍都在抱怨这题恶心）
给我更多的时间说不定能做出来，但我现在只能看题解了

代码

```python
# 

```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==





### 27928: 遍历树

http://cs101.openjudge.cn/practice/27928/



思路：
这题最恶心的地方就是把节点本身也拉进了排序列表，无法通过普通的方式标记“已访问节点”，可以说这个简单的操作让题目难度上升了好几个档次，要不就是基础中的基础
我最终也只能处理样例1


代码

```python
# 
class TreeNode:
    def __init__(self, value):
        self.value = value
        self.children = []

    def add_child(self, child_node):
        if child_node not in self.children:
            self.children.append(child_node)

def build_tree(node_values, connections):
    node_dict = {}

    for value in node_values:
        node_dict[value] = TreeNode(value)

    for parent_value, child_value in connections:
        parent_node = node_dict[parent_value]
        child_node = node_dict[child_value]
        parent_node.add_child(child_node)
        # 添加双向连接
        child_node.add_child(parent_node)

    return node_dict[node_values[0]]

node_values = []
connections = []
n=int(input())
for _ in range(0,n):
    x=list(map(int,input().split()))
    node_values.append(x[0])
    if len(x)>1:
        for i in range(1,len(x)):
            connections.append((x[0],x[i]))
root = build_tree(node_values, connections)

def traverse_tree(node, visited):
    visited.add(node.value)
    sorted_children = sorted(node.children, key=lambda x: x.value)
    smaller_children = [child for child in sorted_children if child.value < node.value and child.value not in visited]
    for child in smaller_children:
        traverse_tree(child, visited)
    print(node.value)
    remaining_children = [child for child in sorted_children if child.value >= node.value and child.value not in visited]
    for child in remaining_children:
        traverse_tree(child, visited)

traverse_tree(root, set())

```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==





## 2. 学习总结和收获

==如果作业题目简单，有否额外练习题目，比如：OJ“2024spring每日选做”、CF、LeetCode、洛谷等网站题目。==
现在我已经掌握了基础的树操作，但是复杂的操作还是不行，比如最后一道题
其实可能主要还是不够了解底层原理导致的



