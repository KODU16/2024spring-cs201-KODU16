# Assignment #8: 图论：概念、遍历，及 树算

Updated 1919 GMT+8 Apr 8, 2024

2024 spring, Complied by ==同学的姓名、院系==



**说明：**

1）请把每个题目解题思路（可选），源码Python, 或者C++（已经在Codeforces/Openjudge上AC），截图（包含Accepted），填写到下面作业模版中（推荐使用 typora https://typoraio.cn ，或者用word）。AC 或者没有AC，都请标上每个题目大致花费时间。

2）提交时候先提交pdf文件，再把md或者doc文件上传到右侧“作业评论”。Canvas需要有同学清晰头像、提交文件有pdf、"作业评论"区有上传的md或者doc附件。

3）如果不能在截止前提交作业，请写明原因。

## 1. 题目

### 19943: 图的拉普拉斯矩阵

matrices, http://cs101.openjudge.cn/practice/19943/

请定义Vertex类，Graph类，然后实现


这题我一开始整成了n行m列的矩阵，能过样例但是就是RE，半天才看出来

代码

```python
# 
n,m=map(int,input().split())
jz = [[0 for _ in range(n)] for _ in range(n)]
jz2 = [[0 for _ in range(n)] for _ in range(n)]
for i in range(0,m):
    x,y=map(int,input().split())
    jz[x][y]=1
    jz[y][x]=1
    jz2[x][x]+=1
    jz2[y][y]+=1
for i in range(0,n):
    for j in range(0,n-1):
        print(jz2[i][j]-jz[i][j],end=" ")
    print(jz2[i][n-1]-jz[i][n-1])
```



代码运行截图 ==（至少包含有"Accepted"）==
[![pFvq7hq.png](https://s21.ax1x.com/2024/04/15/pFvq7hq.png)](https://imgse.com/i/pFvq7hq)
### 18160: 最大连通域面积

matrix/dfs similar, http://cs101.openjudge.cn/practice/18160



一定不要写错向周围八个格子走的部分



代码

```python
# 
maxlt = 0
m = 0
n = 0
mx = [0, 0, 1, -1, 1, -1, 1, -1]
my = [1, -1, 0, 0, 1, 1, -1, -1]

def fs(posx, posy):
    global maxlt
    global m
    global n
    
    if posx < 0 or posx >= n or posy < 0 or posy >= m:
        return 0
    if jz[posx][posy] != 0:
        return 0
    
    jz[posx][posy] = 2
    curmax = 1
    
    for i in range(8):
        curmax += fs(posx + mx[i], posy + my[i])
    
    return curmax

t = int(input())
for o in range(t):
    maxlt = 0
    n, m = map(int, input().split())
    jz = []
    for i in range(n):
        s = input()
        jz.append([0 if c == 'W' else 1 for c in s])
    
    for i in range(n):
        for j in range(m):
            if jz[i][j] == 0:
                maxlt = max(maxlt, fs(i, j))
    
    print(maxlt)

```



代码运行截图 ==（至少包含有"Accepted"）==
[![pFxkPXj.png](https://s21.ax1x.com/2024/04/16/pFxkPXj.png)](https://imgse.com/i/pFxkPXj)
### sy383: 最大权值连通块

https://sunnywhy.com/sfbj/10/3/383



这个图建的有点迫真，非常的不优雅，但好歹是好用的



代码

```python
# 
tu = []
maxlt=0
def fs(cur):
    global maxlt
    if tu[cur][1]==1:
        return 0
    tu[cur][1]=1
    curmax=tu[cur][0]
    if len(tu[cur])>2:
        for i in range(2,len(tu[cur])):
            curmax += fs(tu[cur][i])
    return curmax

n, m = map(int, input().split())
l=list(map(int,input().split()))
for i in range(n):
    tu.append([l[i],0])
for i in range(m):
    x,y=map(int,input().split())
    tu[x].append(y)
    tu[y].append(x)
for i in range(n):
    maxlt = max(maxlt, fs(i))
print(maxlt)
```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==
[![pFxeRne.png](https://s21.ax1x.com/2024/04/16/pFxeRne.png)](https://imgse.com/i/pFxeRne)
### 03441: 4 Values whose Sum is 0

data structure/binary search, http://cs101.openjudge.cn/practice/03441



思路：
二分忘的差不多了，还是看题解解决的




代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==





### 04089: 电话号码

trie, http://cs101.openjudge.cn/practice/04089/

Trie 数据结构可能需要自学下。



思路：我觉得问题出在搜索上，我也不知道具体哪有问题，让我再想想



代码

```python
# 
class TrieNode:
    def __init__(self):
        self.children = {}
        self.is_end_of_word = False

class Trie:
    def __init__(self):
        self.root = TrieNode()
    
    def insert(self, word):
        node = self.root
        for char in word:
            if char not in node.children:
                node.children[char] = TrieNode()
            node = node.children[char]
        node.is_end_of_word = True
    
    def search(self, word):
        node = self.root
        for char in word:
            if char not in node.children:
                return False
            node = node.children[char]
        return node.is_end_of_word
    
    def starts_with(self, prefix):
        node = self.root
        for char in prefix:
            if char not in node.children:
                return False
            node = node.children[char]
        return len(node.children) > 0

t = int(input())
for _ in range(t):
    pd = 0
    wod = []
    n = int(input())
    trie = Trie()
    for i in range(n):
        word = input()
        trie.insert(word)
        wod.append(word)
    for i in range(n):
        wod_except_current = wod[:i] + wod[i+1:]
        if trie.starts_with(wod[i]):
            pd = 1
            break
    if pd == 1:
        print("NO")
    else:
        print("YES")
```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==
没有AC




### 04082: 树的镜面映射

http://cs101.openjudge.cn/practice/04082/



思路：看完题解我才知道“宽度优先遍历”是“广度优先搜索”...
不过还是弄懂了

代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==





## 2. 学习总结和收获

==如果作业题目简单，有否额外练习题目，比如：OJ“2024spring每日选做”、CF、LeetCode、洛谷等网站题目。==
遍历不是简单地走一遍（要不大概率会超时，或者漏掉什么），需要采用合理的数据结构，避开可能会导致错误的方法。