# Assignment #3: March月考

Updated 1537 GMT+8 March 6, 2024

**说明：**

1）The complete process to learn DSA from scratch can be broken into 4 parts:
- Learn about Time and Space complexities
- Learn the basics of individual Data Structures
- Learn the basics of Algorithms
- Practice Problems on DSA

2）请把每个题目解题思路（可选），源码Python, 或者C++（已经在Codeforces/Openjudge上AC），截图（包含Accepted），填写到下面作业模版中（推荐使用 typora https://typoraio.cn ，或者用word）。AC 或者没有AC，都请标上每个题目大致花费时间。

3）提交时候先提交pdf文件，再把md或者doc文件上传到右侧“作业评论”。Canvas需要有同学清晰头像、提交文件有pdf、"作业评论"区有上传的md或者doc附件。

4）如果不能在截止前提交作业，请写明原因。



**编程环境**

## 1. 题目

**02945: 拦截导弹**

http://cs101.openjudge.cn/practice/02945/



思路：
数据不大可以用搜索（其实主要是不想写动规）


##### 代码

```python
# 
ans=0
a=int(input())
l=list(map(int,input().split()))
def dfs(cnt, pos):
    global ans
    cnt+=1
    if cnt>ans:
        ans=cnt
    if pos == a-1:
        return
    else:
        for i in range(pos+1,a):
            if l[i]<=l[pos]:
                dfs(cnt,i)
        return
for i in range(0,a):
    dfs(0,i)
print(ans)
```



代码运行截图 ==（至少包含有"Accepted"）==
[![pF6m1JJ.png](https://s21.ax1x.com/2024/03/11/pF6m1JJ.png)](https://imgse.com/i/pF6m1JJ)
**04147:汉诺塔问题(Tower of Hanoi)**

http://cs101.openjudge.cn/practice/04147



思路：
很典型的递归题


##### 代码

```python
# 
n,s,t,e=input().split()
n=int(n)
def printmove(a,b,c):
    print(a,end="")
    print(":",end="")
    print(b,end="")
    print("->",end="")
    print(c)
def hnt(cur,sta,temp,end):
    if cur==1:
        printmove(1,sta,end)
    else:
        hnt(cur-1,sta,end,temp)
        printmove(cur,sta,end)
        hnt(cur-1,temp,sta,end)
    return
hnt(n,s,t,e)
```



代码运行截图 ==（至少包含有"Accepted"）==
[![pF6nT4e.png](https://s21.ax1x.com/2024/03/11/pF6nT4e.png)](https://imgse.com/i/pF6nT4e)
**03253: 约瑟夫问题No.2**

http://cs101.openjudge.cn/practice/03253



思路：
原先我一个一个加，总是RE，gpt告诉我可以直接取模，会方便很多
不知道python有没有c++的vector这种好用的东西，或许只是我没找着
##### 代码

```c
# 
#include<iostream>
#include<vector>

using namespace std;

int main() {
    int n, p, m;
    while (cin >> n >> p >> m) {
        if (n == 0 && p == 0 && m == 0)
            break;
        vector<int> children(n);
        for (int i = 0; i < n; ++i)
            children[i] = i+1;
        int idx = p-1;
        while (children.size() > 1) {
            idx = (idx + m - 1) % children.size();
            cout << children[idx];
            if (children.size() > 1)
                cout << ",";
            children.erase(children.begin() + idx);
        }
        cout << children[0] << endl;
    }
    return 0;
}
```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==
[![pF6Mk7V.png](https://s21.ax1x.com/2024/03/11/pF6Mk7V.png)](https://imgse.com/i/pF6Mk7V)
**21554:排队做实验 (greedy)v0.2**

http://cs101.openjudge.cn/practice/21554



思路：



##### 代码

```python
# 
n=int(input())
ans=0
l=list(map(int,input().split()))
l_=[]
l__=[]
for i in range(0,n):
    l_.append((i,l[i]))
l_.sort(key=lambda x: x[1])
l__.append(l_[0][1])
for i in range(1,n):
    l__.append(l__[i-1]+l_[i][1])
for i in range(n-2,-1,-1):
    ans+=l__[i]
ans/=n
for i in range(0,n):
    if i==n-1:
        print(l_[n-1][0]+1,end="\n")
    else:
        print(l_[i][0]+1,end=" ")
print("{:.2f}".format(ans))
```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==
![Alt text](image.png)
**19963:买学区房**

http://cs101.openjudge.cn/practice/19963

##### 代码

```python
# 
ans = 0
distances = []
xjb = []
n = int(input())
pairs = [i[1:-1] for i in input().split()]
distances = [sum(map(int, pair.split(','))) for pair in pairs]
prices = list(map(int, input().split()))
for i in range(n):
    xjb.append(distances[i] / prices[i])
s_p = sorted(prices)
s_x = sorted(xjb)
if n % 2 == 1:
    mp = s_p[n // 2]
    mx = s_x[n // 2]
else:
    mp = (s_p[n // 2 - 1] + s_p[n // 2]) / 2
    mx = (s_x[n // 2 - 1] + s_x[n // 2]) / 2
for i in range(n):
    if prices[i] < mp and xjb[i] > mx:
        ans += 1
print(ans)
```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==
[![pF63rrj.png](https://s21.ax1x.com/2024/03/11/pF63rrj.png)](https://imgse.com/i/pF63rrj)
**27300: 模型整理**

http://cs101.openjudge.cn/practice/27300

GPT给我写了一个相当清爽的输出方法，我原先的输出非常累赘
##### 代码

```python
# 
def convert_to_number(s):
    multipliers = {
        'K': 1e3,
        'M': 1e6,
        'B': 1e9,
    }
    unit = s[-1].upper()
    return float(s[:-1]) * multipliers[unit]

def custom_sort(t):
    return (t[0], t[2])

k = int(input())
l = []

for i in range(k):
    n, m = input().split('-')
    l.append((n, m))

l_ = [(n, m, convert_to_number(m)) for n, m in l]

s_l = sorted(l_, key=custom_sort)

current_model = ""
for name, param, _ in s_l:
    if name != current_model:
        if current_model != "":
            print()
        print(f"{name}: {param}", end="")
        current_model = name
    else:
        print(f", {param}", end="")
print()
```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==
[![pF6aQu8.png](https://s21.ax1x.com/2024/03/11/pF6aQu8.png)](https://imgse.com/i/pF6aQu8)
## 2. 学习总结和收获
有的时候需要反着来，反过来计数会比正向更快，更易于操作



