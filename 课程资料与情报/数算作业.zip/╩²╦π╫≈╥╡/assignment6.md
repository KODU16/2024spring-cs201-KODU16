# Assignment #6: "树"算：Huffman,BinHeap,BST,AVL,DisjointSet

Updated 2214 GMT+8 March 24, 2024

2024 spring, Complied by ==同学的姓名、院系==



**说明：**

1）这次作业内容不简单，耗时长的话直接参考题解。

2）请把每个题目解题思路（可选），源码Python, 或者C++（已经在Codeforces/Openjudge上AC），截图（包含Accepted），填写到下面作业模版中（推荐使用 typora https://typoraio.cn ，或者用word）。AC 或者没有AC，都请标上每个题目大致花费时间。

3）提交时候先提交pdf文件，再把md或者doc文件上传到右侧“作业评论”。Canvas需要有同学清晰头像、提交文件有pdf、"作业评论"区有上传的md或者doc附件。

4）如果不能在截止前提交作业，请写明原因。



**编程环境**

==（请改为同学的操作系统、编程环境等）==

操作系统：macOS Ventura 13.4.1 (c)

Python编程环境：Spyder IDE 5.2.2, PyCharm 2023.1.4 (Professional Edition)

C/C++编程环境：Mac terminal vi (version 9.0.1424), g++/gcc (Apple clang version 14.0.3, clang-1403.0.22.14.1)



## 1. 题目

### 22275: 二叉搜索树的遍历

http://cs101.openjudge.cn/practice/22275/



思路：
相比之前的题目，主要难在没有了中序遍历做参考，如何确定节点的位置新子树还是原子树的子节点
令人疑惑的是，gpt坚持认为只给定前序遍历是无法建树的，后来我才发现我一直问的是“二叉树”行不行，的确，一般的二叉树确实没法通过一个遍历建树。

代码

```python
# 
class TreeNode:
    def __init__(self, value):
        self.val = value
        self.left = None
        self.right = None

def build_tree(preorder):
    if not preorder:
        return None

    def helper(lower, upper):
        nonlocal index
        if index == len(preorder):
            return None
        
        value = int(preorder[index])
        if value < lower or value > upper:
            return None
        
        index += 1
        node = TreeNode(value)
        node.left = helper(lower, value)
        node.right = helper(value, upper)
        return node

    index = 0
    return helper(float('-inf'), float('inf'))

def postorder_traversal(node, result):
    if not node:
        return
    postorder_traversal(node.left, result)
    postorder_traversal(node.right, result)
    result.append(node.val)

n = int(input())
preorder = input().split()
root = build_tree(preorder)
postorder_result = []
postorder_traversal(root, postorder_result)
for i in range(n):
    if i == n - 1:
        print(postorder_result[i], end="")
    else:
        print(postorder_result[i], end=" ")

```



代码运行截图 ==（至少包含有"Accepted"）==
[![pFoL5HU.png](https://s21.ax1x.com/2024/03/29/pFoL5HU.png)](https://imgse.com/i/pFoL5HU)
### 05455: 二叉搜索树的层次遍历

http://cs101.openjudge.cn/practice/05455/

这道题我莫名其妙地只能输出四个数，看到题解后，发现我对重复的数据处理有问题

### 04078: 实现堆结构

http://cs101.openjudge.cn/practice/04078/

练习自己写个BinHeap。当然机考时候，如果遇到这样题目，直接import heapq。手搓栈、队列、堆、AVL等，考试前需要搓个遍。



思路：
我的离谱想法让我直接提取“第三位”作为应该加入堆的元素，后来改正就能过了
代码
gpt写的手搓版本
```python
# 
class MinHeap:
    def __init__(self):
        self.heap = []

    def add_element(self, value):
        self.heap.append(value)
        self._heapify_up(len(self.heap) - 1)

    def pop_min(self):
        if not self.heap:
            return None
        if len(self.heap) == 1:
            return self.heap.pop()
        self._swap(0, len(self.heap) - 1)
        min_value = self.heap.pop()
        self._heapify_down(0)
        return min_value

    def _heapify_up(self, index):
        while index > 0:
            parent_index = (index - 1) // 2
            if self.heap[parent_index] > self.heap[index]:
                self._swap(parent_index, index)
                index = parent_index
            else:
                break

    def _heapify_down(self, index):
        size = len(self.heap)
        while index < size:
            left_child_index = 2 * index + 1
            right_child_index = 2 * index + 2
            min_index = index

            if left_child_index < size and self.heap[left_child_index] < self.heap[min_index]:
                min_index = left_child_index
            if right_child_index < size and self.heap[right_child_index] < self.heap[min_index]:
                min_index = right_child_index

            if min_index != index:
                self._swap(index, min_index)
                index = min_index
            else:
                break

    def _swap(self, i, j):
        self.heap[i], self.heap[j] = self.heap[j], self.heap[i]

min_heap = MinHeap()
n=int(input())
for i in range(n):
    step=input()
    if step[0]=='2':
        print(min_heap.pop_min())       
    else:
        t=list(step.split())
        min_heap.add_element(int(t[1]))

```
自己写的import heapq版本
```python
# 
import heapq

class MinHeap:
    def __init__(self):
        self.heap = []

    def add_element(self, value):
        heapq.heappush(self.heap, value)

    def pop_min(self):
        if self.heap:
            return heapq.heappop(self.heap)
        else:
            return None

min_heap = MinHeap()
n=int(input())
for i in range(n):
    step=input()
    if step[0]=='2':
        print(min_heap.pop_min())       
    else:
        t=list(step.split())
        min_heap.add_element(int(t[1]))

```


代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==
[![pFoj74g.png](https://s21.ax1x.com/2024/03/29/pFoj74g.png)](https://imgse.com/i/pFoj74g)
### 22161: 哈夫曼编码树

http://cs101.openjudge.cn/practice/22161/

这个我上课就没太整明白，只能一边看题解一边问gpt给我讲讲了

### 晴问9.5: 平衡二叉树的建立

https://sunnywhy.com/sfbj/9/5/359



思路：
主要难点在于如何旋转整棵树


代码

```python
# 
class TreeNode:
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None
        self.height = 1

class AVLTree:
    def insert(self, root, key):
        if not root:
            return TreeNode(key)
        elif key < root.key:
            root.left = self.insert(root.left, key)
        else:
            root.right = self.insert(root.right, key)

        root.height = 1 + max(self.get_height(root.left), self.get_height(root.right))

        balance = self.get_balance(root)

        if balance > 1 and key < root.left.key:
            return self.rotate_right(root)
        if balance < -1 and key > root.right.key:
            return self.rotate_left(root)
        if balance > 1 and key > root.left.key:
            root.left = self.rotate_left(root.left)
            return self.rotate_right(root)
        if balance < -1 and key < root.right.key:
            root.right = self.rotate_right(root.right)
            return self.rotate_left(root)

        return root

    def rotate_left(self, z):
        y = z.right
        T2 = y.left

        y.left = z
        z.right = T2

        z.height = 1 + max(self.get_height(z.left), self.get_height(z.right))
        y.height = 1 + max(self.get_height(y.left), self.get_height(y.right))

        return y

    def rotate_right(self, y):
        x = y.left
        T2 = x.right

        x.right = y
        y.left = T2

        y.height = 1 + max(self.get_height(y.left), self.get_height(y.right))
        x.height = 1 + max(self.get_height(x.left), self.get_height(x.right))

        return x

    def get_height(self, root):
        if not root:
            return 0
        return root.height

    def get_balance(self, root):
        if not root:
            return 0
        return self.get_height(root.left) - self.get_height(root.right)
    def pre_order_traversal(self, root):
        def _pre_order_traversal(node):
            nonlocal result
            if node:
                result += str(node.key) + " "
                _pre_order_traversal(node.left)
                _pre_order_traversal(node.right)

        result = ""
        _pre_order_traversal(root)
        print(result.strip())

avl_tree = AVLTree()
root = None
n=input()
keys_to_insert = list(map(int,input().split()))
for key in keys_to_insert:
    root = avl_tree.insert(root, key)

avl_tree.pre_order_traversal(root)

```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==
[![pFTFkxU.png](https://s21.ax1x.com/2024/03/29/pFTFkxU.png)](https://imgse.com/i/pFTFkxU)




### 02524: 宗教信仰

http://cs101.openjudge.cn/practice/02524/



思路：
输出格式的调整很烦人，输样例也是
代码

```python
# 
class DSU:
    def __init__(self, n):
        self.parent = list(range(n))
        self.rank = [0] * n

    def find(self, x):
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])
        return self.parent[x]

    def union(self, x, y):
        root_x, root_y = self.find(x), self.find(y)
        if root_x != root_y:
            if self.rank[root_x] > self.rank[root_y]:
                self.parent[root_y] = root_x
            else:
                self.parent[root_x] = root_y
                if self.rank[root_x] == self.rank[root_y]:
                    self.rank[root_y] += 1

def estimate_religions(students, relationships):
    global n
    dsu = DSU(n)

    for a, b in relationships:
        dsu.union(a, b)

    religions = set()
    for i in range(n):
        religions.add(dsu.find(i))

    return len(religions)
cnt=0
res=[]
while True:
    n,m = map(int, input().split())
    if n==0 and m==0:
        break
    students=[]
    students = list(range(n))
    relationships = []
    for i in range(m):
        x,y = map(int, input().split())
        relationships.append((x-1,y-1))
    result = estimate_religions(students, relationships)
    res.append(result)
for i in range(0,len(res)):
    print("Case",i+1,end="")
    print(": ",end="")
    if i== len(res)-1:
        print(res[i],end="")
    else:
        print(res[i])       
```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==
[![pFovIMR.png](https://s21.ax1x.com/2024/03/29/pFovIMR.png)](https://imgse.com/i/pFovIMR)




## 2. 学习总结和收获
许多数据格式，都可以归结为树的操作与运算，只不过这个“树”可以是各种的变种或是加入限制要求，掌握了“树”的基本结构，那后面的附加就会变得更容易



