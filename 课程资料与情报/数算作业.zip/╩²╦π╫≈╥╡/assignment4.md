# Assignment #4: 排序、栈、队列和树

Updated 0005 GMT+8 March 11, 2024

2024 spring, Complied by ==同学的姓名、院系==



**说明：**

1）The complete process to learn DSA from scratch can be broken into 4 parts:

Learn about Time complexities, learn the basics of individual Data Structures, learn the basics of Algorithms, and practice Problems.

2）请把每个题目解题思路（可选），源码Python, 或者C++（已经在Codeforces/Openjudge上AC），截图（包含Accepted），填写到下面作业模版中（推荐使用 typora https://typoraio.cn ，或者用word）。AC 或者没有AC，都请标上每个题目大致花费时间。

3）提交时候先提交pdf文件，再把md或者doc文件上传到右侧“作业评论”。Canvas需要有同学清晰头像、提交文件有pdf、"作业评论"区有上传的md或者doc附件。

4）如果不能在截止前提交作业，请写明原因。

## 1. 题目

### 05902: 双端队列

http://cs101.openjudge.cn/practice/05902/



思路：



代码

```python
# 
t = int(input())
for _ in range(t):
    m = int(input())
    lb = []
    for i in range(m):
        x, y = map(int, input().split())
        if x == 1:
            lb.append(y)
        if x == 2:
            if y == 0:
                lb.pop(0)
            else:
                lb.pop()
    if len(lb) == 0:
        print("NULL")
    else:
        print(" ".join(map(str, lb)))
```

代码运行截图 ==（至少包含有"Accepted"）==
[![pF2xjSK.png](https://s21.ax1x.com/2024/03/18/pF2xjSK.png)](https://imgse.com/i/pF2xjSK)




### 02694: 波兰表达式

http://cs101.openjudge.cn/practice/02694/



思路：
一开始我存了符号栈和数字栈两个栈，但总是不能解决* + + 1 1 1 1 和* + 11.0 12.0 + 24.0 35.0中的一个
后来查了一下，通过从后往前遍历，符号不存栈，从而解决了问题
代码

```python
# 
def is_float(s):
    try:
        float(s)
        return True
    except ValueError:
        return False
t = input().split()
num = []
for i in reversed(t):
    if is_float(i):
        num.insert(0,i)
    else:
        if i=='+':
            res=float(num[0])+float(num[1])
        if i=='-':
            res=float(num[0])-float(num[1])
        if i=='*':
            res=float(num[0])*float(num[1])
        if i=='/':
            res=float(num[0])/float(num[1])
        num.pop(0)
        num.pop(0)
        num.insert(0,res)
formatted_num = "%.6f" % num[0]
print(formatted_num)
```



代码运行截图 ==（至少包含有"Accepted"）==
[![pFRAa7T.png](https://s21.ax1x.com/2024/03/18/pFRAa7T.png)](https://imgse.com/i/pFRAa7T)




### 24591: 中序表达式转后序表达式

http://cs101.openjudge.cn/practice/24591/



思路：
一开始我用的比较运算符号次序的方法很麻烦，gpt建议我用这种次序列表
代码

```python
# 
def infix_to_postfix(infix):
    precedence = {'+': 1, '-': 1, '*': 2, '/': 2}
    stack = []
    postfix = []
    number = ''
    for char in infix:
        if char.isdigit() or char == '.':
            number += char
        else:
            if number:
                postfix.append(number)
                number = ''
            if char == '(':
                stack.append(char)
            elif char == ')':
                while stack and stack[-1] != '(':
                    postfix.append(stack.pop())
                if stack and stack[-1] == '(':
                    stack.pop()
            elif char in precedence:
                while stack and precedence.get(stack[-1], 0) >= precedence.get(char, 0):
                    postfix.append(stack.pop())
                stack.append(char)
    if number:
        postfix.append(number)
    while stack:
        postfix.append(stack.pop())
    
    return ' '.join(postfix)
n = int(input())
expressions = []
for _ in range(n):
    expression = input()
    expressions.append(expression)

for exp in expressions:
    print(infix_to_postfix(exp))
```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==
[![pFRtRbT.png](https://s21.ax1x.com/2024/03/18/pFRtRbT.png)](https://imgse.com/i/pFRtRbT)
### 22068: 合法出栈序列

http://cs101.openjudge.cn/practice/22068/



思路：
这题我想了很久，问gpt也不明白，看了题解才知道这里的栈怎么用的
代码

```python
# 

```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==





### 06646: 二叉树的深度

http://cs101.openjudge.cn/practice/06646/



思路：
数据很小，用搜索就行
代码

```python
# 
s=[]
s.append((0,-1,-1))
ans=0
def search(cnt,cur):
    global ans
    if s[cur][1]==-1 and s[cur][2] ==-1:
        if cnt>ans:
            ans=cnt
        return
    else:
        if s[cur][1]!=-1:
            search(cnt+1,s[cur][1])
        if s[cur][2]!=-1:
            search(cnt+1,s[cur][2])
n=int(input())
for i in range(n):
    x,y=map(int,input().split())
    s.append((i+1,x,y))
search(1,1)
print(ans)
```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==
[![pFRJ9x0.png](https://s21.ax1x.com/2024/03/18/pFRJ9x0.png)](https://imgse.com/i/pFRJ9x0)
### 02299: Ultra-QuickSort

http://cs101.openjudge.cn/practice/02299/



思路：
这题的时间有点严格...没过
代码

```python
# 

```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==





## 2. 学习总结和收获

==如果作业题目简单，有否额外练习题目，比如：OJ“2024spring每日选做”、CF、LeetCode、洛谷等网站题目。==
Python的那个顺序表是个很有用的东西，会了之后就不用再逐一比对得出大小关系，直接就能自定义字典序