# Assignment #2: 编程练习

Updated 0953 GMT+8 Feb 24, 2024

2024 spring, Complied by 熊奕凯

## 1. 题目

### 27653: Fraction类

http://cs101.openjudge.cn/practice/27653/

##### 代码

```python
# 
import math
a,b,c,d = map(int, input().split())
e=int(a*d+b*c)
f=int(b*d)
g=min(e,f)
i=2
while i < int(math.sqrt(g)+1):
    if e%i==0 and f%i==0:
        e=int(e/i)
        f=int(f/i)
        i=2
    else:
        i+=1
print(e,end="/")
print(f)
```



代码运行截图 ==（至少包含有"Accepted"）==
[![pFs5aGV.png](https://s21.ax1x.com/2024/03/09/pFs5aGV.png)](https://imgse.com/i/pFs5aGV)




### 04110: 圣诞老人的礼物-Santa Clau’s Gifts

greedy/dp, http://cs101.openjudge.cn/practice/04110

##### 代码

```c
# 
#include<iostream>
#include<algorithm>
#include <iomanip>
#include <cmath>
#include <sstream>
using namespace std;
int tg[1000],jz[1000];
double yx[1000],ans=0;

std::string roundTo1Decimal(double num) {
    int roundedNum = std::round(num * 10);
    int integerPart = roundedNum / 10;
    int decimalPart = roundedNum % 10;
    std::stringstream ss;
    ss << integerPart;
    if (decimalPart != 0) {
        ss << "." << decimalPart;
    } else {
        ss << ".0";
    }

    return ss.str();
}
int main()
{
	int n,w;
	cin >> n >> w;
	for(int i=1; i<=n; ++i)
	{
		int x,y;
		cin >> x >> y;
		tg[i]=y;
		jz[i]=x;
		yx[i]=x/y;
	}
	yx[0]=-1;
	//sort(yx,yx+n);
	while(w>0)
	{
		int mi=0;
		for(int i=1; i<=n; ++i)
		{
			if(yx[i]>yx[mi])
			{
				mi=i;		
			}
		}
		if(mi==0)
			break;
		if(w>tg[mi])	
		{
			yx[mi]=-1;
			ans+=jz[mi];
			w-=tg[mi];
		}
		else
		{
			ans+=yx[mi]*w;
			w=0;
			//cout << (w/tg[mi])*jz[mi] << endl;
		}
	}
    std::string roundedNum2 = roundTo1Decimal(ans);
    std::cout << roundedNum2 << std::endl;
	return 0;
}
```



代码运行截图 ==（至少包含有"Accepted"）==
[![pFyvLCD.png](https://s21.ax1x.com/2024/03/10/pFyvLCD.png)](https://imgse.com/i/pFyvLCD)
### 18182: 打怪兽

implementation/sortings/data structures, http://cs101.openjudge.cn/practice/18182/

##### 代码

```python
# 
nc = int(input())
for _ in range(nc):
    n, m, b = map(int, input().split())
    skills = {}
    for _ in range(n):
        t, y = map(int, input().split())
        if t not in skills:
            skills[t] = []
        skills[t].append(y)
    ans = 0
    t=sorted(list(skills.keys()))
    for i in t:
        skills[i].sort(reverse=True)
        if len(skills[i])<m:
            b-=sum(skills[i])
        else:
            b-=sum(skills[i][0:m])
        if b <= 0:
            ans = i
            break
    if ans == 0:
        print("alive")
    else:
        print(ans)
```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==
[![pFyx6sA.png](https://s21.ax1x.com/2024/03/10/pFyx6sA.png)](https://imgse.com/i/pFyx6sA)
### 230B. T-primes

binary search/implementation/math/number theory, 1300, http://codeforces.com/problemset/problem/230/B

##### 代码

```python
# 
import math

def is_perfect_square(num):
    if num < 0:
        return False
    sqrt_num = int(math.sqrt(num))
    return sqrt_num * sqrt_num == num

def sieve_of_eratosthenes(limit):
    is_prime = [True] * (limit + 1)
    is_prime[0] = is_prime[1] = False
    for i in range(2, int(math.sqrt(limit)) + 1):
        if is_prime[i]:
            for j in range(i * i, limit + 1, i):
                is_prime[j] = False
    primes = [num for num in range(2, limit + 1) if is_prime[num]]
    return primes

def binary_search(arr, target):
    left, right = 0, len(arr) - 1
    while left <= right:
        mid = left + (right - left) // 2
        if arr[mid] == target:
            return True
        elif arr[mid] < target:
            left = mid + 1
        else:
            right = mid - 1
    return False

primes_list = sieve_of_eratosthenes(10**6)

n=int(input())
m=list(map(int,input().split()))
for num in m:
    if is_perfect_square(num):
        if binary_search(primes_list, int(math.sqrt(num))):
            print("YES")
        else:
            print("NO")
    else:
        print("NO")
```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==
[![pFyxOoV.png](https://s21.ax1x.com/2024/03/11/pFyxOoV.png)](https://imgse.com/i/pFyxOoV)



### 1364A. XXXXX

brute force/data structures/number theory/two pointers, 1200, https://codeforces.com/problemset/problem/1364/A

##### 代码

```python
# 
def find_longest_subsequence(nums, k):
    n = len(nums)
    if nums[n-1]%k!=0:
        return n
    for j in range(1,n):
        if nums[n-1-j]%k!=0 or (nums[n-1]-nums[j-1])%k!=0:
            return n-j
    return -1
n=int(input())
for _ in range(n):
    b,x=map(int,input().split())
    l=list(map(int,input().split()))
    lsum=[]
    lsum.append(l[0])
    for i in range(1,len(l)):
        lsum.append(lsum[i-1]+l[i])
    ans=find_longest_subsequence(lsum,x)
    print(ans)
```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==
[![pF6iEFI.png](https://s21.ax1x.com/2024/03/11/pF6iEFI.png)](https://imgse.com/i/pF6iEFI)
### 18176: 2050年成绩计算

http://cs101.openjudge.cn/practice/18176/

##### 代码

```python
# 
import math

def is_zs(n):
    if n <= 1:
        return False
    for i in range(2, int(math.sqrt(n)) + 1):
        if n % i == 0:
            return False
    return True

def is_square_of_prime(num):
    if num < 2:
        return False
    root = math.sqrt(num)
    if root.is_integer():
        return is_zs(int(root))
    return False

n, m = map(int, input().split())
for _ in range(n):
    ans=0
    a = list(map(int, input().split()))
    s = len(a)
    for i in range(0,s):
        if is_square_of_prime(a[i]):
            ans+=a[i]
    if ans == 0:
        print("0")
    else:
        formatted_num = "{:.2f}".format(ans / s)
        print(formatted_num)
```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==
没ac，卡常好恶心...
## 2. 学习总结和收获
数学不好的人玩不好计算机题，那个序列我的确没想到必定在头尾



