# Assignment #D: May月考

Updated 1654 GMT+8 May 8, 2024

2024 spring, Complied by ==同学的姓名、院系==



**说明：**

1）请把每个题目解题思路（可选），源码Python, 或者C++（已经在Codeforces/Openjudge上AC），截图（包含Accepted），填写到下面作业模版中（推荐使用 typora https://typoraio.cn ，或者用word）。AC 或者没有AC，都请标上每个题目大致花费时间。

2）提交时候先提交pdf文件，再把md或者doc文件上传到右侧“作业评论”。Canvas需要有同学清晰头像、提交文件有pdf、"作业评论"区有上传的md或者doc附件。

3）如果不能在截止前提交作业，请写明原因。

## 1. 题目

### 02808: 校门外的树

http://cs101.openjudge.cn/practice/02808/



思路：
我初中学c++的时候应该采用过另外一种思路，但是我不记得了


代码

```python
# 
def merge_intervals(intervals):
    if not intervals:
        return []

    intervals.sort(key=lambda x: x[0])
    merged = [intervals[0]]

    for interval in intervals[1:]:
        prev_end = merged[-1][1]
        if interval[0] <= prev_end:
            merged[-1] = (merged[-1][0], max(prev_end, interval[1]))
        else:
            merged.append(interval)

    return merged

intervals = []
l, m = map(int, input().split())
l += 1
for i in range(m):
    x, y = map(int, input().split())
    intervals.append((x, y))

overall = merge_intervals(intervals)
trees_left = l

for start, end in overall:
    trees_left -= (end - start + 1)

print(trees_left)

```



代码运行截图 ==（至少包含有"Accepted"）==
[![pkeo0gS.png](https://s21.ax1x.com/2024/05/12/pkeo0gS.png)](https://imgse.com/i/pkeo0gS)




### 20449: 是否被5整除

http://cs101.openjudge.cn/practice/20449/



思路：
判断二进制能否被5整除时，要采用更快的办法


代码

```python
# 
def can_be_divided_by_5(binary):
    remainder = 0
    for digit in binary:
        remainder = remainder * 2 + int(digit)
        if remainder >= 5:
            remainder -= 5
    return remainder == 0
def ebp(binary_number, k):
    prefix_binary = binary_number[:k]
    return prefix_binary
n=input()
for i in range(len(n)):
    pb = ebp(n, i+1)
    if can_be_divided_by_5(pb):
        print('1',end='')
    else:
        print('0',end='')
```



代码运行截图 ==（至少包含有"Accepted"）==
[![pkeogNq.png](https://s21.ax1x.com/2024/05/12/pkeogNq.png)](https://imgse.com/i/pkeogNq)




### 01258: Agri-Net

http://cs101.openjudge.cn/practice/01258/


对边和权值的判断不是很擅长，看了题解

### 27635: 判断无向图是否连通有无回路(同23163)

http://cs101.openjudge.cn/practice/27635/



思路：
一开始错在没法判断三角环，现在解决了
代码

```python
# 
loop = False
connect = False
graph = []
visited = []

def bfs_loop(pre, cur):
    global visited, loop
    visited.append(cur)
    for i in graph[cur]:
        if i in visited and i != pre:
            loop = True
        elif i not in visited:
            bfs_loop(cur, i)
    return

n, m = map(int, input().split())
for i in range(n):
    graph.append([])
for i in range(m):
    x, y = map(int, input().split())
    graph[x].append(y)
    graph[y].append(x)

all_visited = set()

for i in range(n):
    if i in all_visited:
        continue
    visited = []
    bfs_loop(-1, i)

    all_visited.update(visited)
    if len(visited) == n:
        connect = True

print("connected:", end='')
if connect:
    print("yes")
else:
    print("no")
print("loop:", end='')
if loop:
    print("yes")
else:
    print("no")
```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==
[![pkeTmrQ.png](https://s21.ax1x.com/2024/05/12/pkeTmrQ.png)](https://imgse.com/i/pkeTmrQ)
### 27947: 动态中位数

http://cs101.openjudge.cn/practice/27947/



思路：
当时没来得及同步格式，只把排序写完了
大概是分了左堆和右堆，这样中间的元素就是中位数
后面看了题解


代码

```python
# 
import heapq

class MedianFinder:
    def __init__(self):
        self.max_heap = []
        self.min_heap = []

    def addNum(self, num):
        heapq.heappush(self.max_heap, -num)
        heapq.heappush(self.min_heap, -heapq.heappop(self.max_heap))
        if len(self.min_heap) > len(self.max_heap):
            heapq.heappush(self.max_heap, -heapq.heappop(self.min_heap))

    def findMedian(self):
        if len(self.max_heap) == len(self.min_heap):
            return (-self.max_heap[0] + self.min_heap[0]) / 2
        else:
            return -self.max_heap[0]

median_finder = MedianFinder()

count = 0
while True:
    num = int(input())
    median_finder.addNum(num)
    count += 1
    if count % 2 == 1:
        print(median_finder.findMedian())
```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==





### 28190: 奶牛排队

http://cs101.openjudge.cn/practice/28190/



思路：
想明白要用栈写了，样例也能过，但是没做对
看了题解了


代码

```python
# 
def max_cows(heights):
    stack = []
    max_cow_count = 0

    for height in heights:
        while stack and height <= stack[-1]:
            stack.pop()
        stack.append(height)
        max_cow_count = max(max_cow_count, len(stack))

    return max_cow_count

heights=[]
n=int(input())
for i in range(n):
    x=int(input())
    heights.append(x)
print(max_cows(heights))

```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==





## 2. 学习总结和收获

==如果作业题目简单，有否额外练习题目，比如：OJ“2024spring每日选做”、CF、LeetCode、洛谷等网站题目。==
实际上应该养成写def功能+调用的程序格式，方便记忆基本代码，也方便排查问题