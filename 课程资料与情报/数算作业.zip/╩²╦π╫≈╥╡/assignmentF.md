# Assignment #F: All-Killed 满分

Updated 1844 GMT+8 May 20, 2024

2024 spring, Complied by ==同学的姓名、院系==



**说明：**

1）请把每个题目解题思路（可选），源码Python, 或者C++（已经在Codeforces/Openjudge上AC），截图（包含Accepted），填写到下面作业模版中（推荐使用 typora https://typoraio.cn ，或者用word）。AC 或者没有AC，都请标上每个题目大致花费时间。

2）提交时候先提交pdf文件，再把md或者doc文件上传到右侧“作业评论”。Canvas需要有同学清晰头像、提交文件有pdf、"作业评论"区有上传的md或者doc附件。

3）如果不能在截止前提交作业，请写明原因。

## 1. 题目

### 22485: 升空的焰火，从侧面看

http://cs101.openjudge.cn/practice/22485/



思路：
借这个练一下最简单的二叉树


代码

```python
# 
from collections import deque

class TreeNode:
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None

def build_tree_from_input(nodes_input):
    if not nodes_input:
        return None

    nodes = []
    for key in range(1, len(nodes_input) + 1):
        nodes.append(TreeNode(key))

    for i, (left, right) in enumerate(nodes_input):
        if left != -1:
            nodes[i].left = nodes[left - 1]
        if right != -1:
            nodes[i].right = nodes[right - 1]

    return nodes[0]  # 根节点

def find_rightmost_nodes(root):
    if not root:
        return []
    
    rightmost_nodes = []
    queue = deque([root])
    
    while queue:
        level_size = len(queue)
        for i in range(level_size):
            node = queue.popleft()
            if i == level_size - 1:
                rightmost_nodes.append(node.key)
            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)
    
    return rightmost_nodes
nodes_input=[]
n=int(input())
for i in range(n):
    x,y=map(int,input().split())
    nodes_input.append((x,y))
root = build_tree_from_input(nodes_input)
rightmost_nodes = find_rightmost_nodes(root)
output = ' '.join(map(str, rightmost_nodes))
print(output)

```



代码运行截图 ==（至少包含有"Accepted"）==
[![pk1ES5F.png](https://s21.ax1x.com/2024/05/27/pk1ES5F.png)](https://imgse.com/i/pk1ES5F)




### 28203:【模板】单调栈

http://cs101.openjudge.cn/practice/28203/



思路：
用jion会MLE，因为字符串太长了


代码

```python
# 
def next_greater_elements_indices(nums):
    n = len(nums)
    result = [0] * n
    stack = []

    for i in range(n):
        while stack and nums[i] > nums[stack[-1]]:
            index = stack.pop()
            result[index] = i+1
        stack.append(i)
    
    return result
n=int(input())

nums = list(map(int,input().split()))
result=next_greater_elements_indices(nums)
for i in range(n-1):
    print(result[i],end=' ')
print(result[n-1])
```



代码运行截图 ==（至少包含有"Accepted"）==
[![pk1VuwV.png](https://s21.ax1x.com/2024/05/27/pk1VuwV.png)](https://imgse.com/i/pk1VuwV)




### 09202: 舰队、海域出击！

http://cs101.openjudge.cn/practice/09202/



思路：
要注意节点从0还是1开始


代码

```python
# 
def has_cycle(edges, num_nodes):
    def dfs(node):
        if visited[node] == 1:
            return True
        if visited[node] == 2:
            return False
        visited[node] = 1
        for neighbor in graph[node]:
            if dfs(neighbor):
                return True
        visited[node] = 2
        return False

    graph = [[] for _ in range(num_nodes)]
    for a, b in edges:
        graph[a - 1].append(b - 1)

    visited = [0] * num_nodes

    for node in range(num_nodes):
        if visited[node] == 0:
            if dfs(node):
                return True
    return False

x = int(input())
for _ in range(x):
    num_nodes, e = map(int, input().split())
    edges = []
    for _ in range(e):
        x, y = map(int, input().split())
        edges.append((x, y))
    output = "Yes" if has_cycle(edges, num_nodes) else "No"
    print(output)

```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==
[![pk1eDsA.png](https://s21.ax1x.com/2024/05/27/pk1eDsA.png)](https://imgse.com/i/pk1eDsA)




### 04135: 月度开销

http://cs101.openjudge.cn/practice/04135/



思路：
要先用二分查找看看数组总和和数组最大值的mid能不能划分出来，然后继续缩小


代码

```python
# 
def split_array(nums, m):
    def can_split(nums, m, max_sum):
        count, current_sum = 1, 0
        for num in nums:
            current_sum += num
            if current_sum > max_sum:
                count += 1
                current_sum = num
                if count > m:
                    return False
        return True

    left, right = max(nums), sum(nums)
    while left < right:
        mid = (left + right) // 2
        if can_split(nums, m, mid):
            right = mid
        else:
            left = mid + 1
    return left
nums=[]
n,m=map(int,input().split())
for i in range(n):
    x=int(input())
    nums.append(x)
print(split_array(nums, m))
```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==
[![pk1mCo6.png](https://s21.ax1x.com/2024/05/27/pk1mCo6.png)](https://imgse.com/i/pk1mCo6)




### 07735: 道路

http://cs101.openjudge.cn/practice/07735/



思路：
我忘记最小权值怎么写了，所以看了题解

### 01182: 食物链

http://cs101.openjudge.cn/practice/01182/



思路：
太复杂了，题解也不能完全看懂，努力理解吧
## 2. 学习总结和收获

==如果作业题目简单，有否额外练习题目，比如：OJ“2024spring每日选做”、CF、LeetCode、洛谷等网站题目。==
现在应该开始背一些常见的结构了，比如二叉树，堆和图怎么构建