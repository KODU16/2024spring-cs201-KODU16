# Assignment #B: 图论和树算

Updated 1709 GMT+8 Apr 28, 2024

2024 spring, Complied by ==同学的姓名、院系==



**说明：**

1）请把每个题目解题思路（可选），源码Python, 或者C++（已经在Codeforces/Openjudge上AC），截图（包含Accepted），填写到下面作业模版中（推荐使用 typora https://typoraio.cn ，或者用word）。AC 或者没有AC，都请标上每个题目大致花费时间。

2）提交时候先提交pdf文件，再把md或者doc文件上传到右侧“作业评论”。Canvas需要有同学清晰头像、提交文件有pdf、"作业评论"区有上传的md或者doc附件。

3）如果不能在截止前提交作业，请写明原因。



**编程环境**

==（请改为同学的操作系统、编程环境等）==

操作系统：macOS Ventura 13.4.1 (c)

Python编程环境：Spyder IDE 5.2.2, PyCharm 2023.1.4 (Professional Edition)

C/C++编程环境：Mac terminal vi (version 9.0.1424), g++/gcc (Apple clang version 14.0.3, clang-1403.0.22.14.1)



## 1. 题目

### 28170: 算鹰

dfs, http://cs101.openjudge.cn/practice/28170/



思路：
这回我真没想明白自己为啥过不了


代码

```python
# 
jz=[]
ans=0
for i in range(0,10):
    s=input()
    jz.append(s)
def dfs(x,y):
    global ans
    if jz[x-1][y]=='.' and jz[x+1][y]=='.' and jz[x][y-1]=='.' and jz[x][y+1]=='.':
        ans+=1
for i in range(1,9):
    for j in range(1,9):
        if jz[i][j]=='.':
            dfs(i,j)
print(ans)
```



代码运行截图 ==（至少包含有"Accepted"）==





### 02754: 八皇后

dfs, http://cs101.openjudge.cn/practice/02754/



思路：
很简单的题，但是脑子抽了一下，ai帮我指出来了我的*10位置不对


代码

```python
# 
def chaxun(x1, y1, x2, y2):
    if x2 == x1 or y2 == y1 or abs(x2 - x1) == abs(y2 - y1):
        return True
    return False

def dfs(hang, place, curhh):
    global ans
    if hang == 8:
        ans.append(place)
        return
    for i in range(1, 9):
        flag = True
        for j in range(hang):
            if chaxun(curhh[j][0], curhh[j][1], hang, i):
                flag = False
                break
        if flag:
            curhh.append((hang, i))
            dfs(hang + 1, place * 10 + i, curhh)  # 修改这里，不再乘以10
            curhh.pop()

ans = []
dfs(0, 0, [])
ans = sorted(ans)
n = int(input())
for i in range(n):
    x=int(input())
    print(ans[x-1])
```



代码运行截图 ==（至少包含有"Accepted"）==
[![pkEaZxH.png](https://s21.ax1x.com/2024/05/06/pkEaZxH.png)](https://imgse.com/i/pkEaZxH)




### 03151: Pots

bfs, http://cs101.openjudge.cn/practice/03151/



思路：
其实所有bfs的题都可以归结为“走迷宫”，只不过下一步的操作未必是相似的移动，也可能是这样的倒水，彼此不太相同
判断可不可行，用到了裴蜀定理，是个有意思的知识


代码

```python
# 
import math
from collections import deque

def bfs(m, n, x):
    visited = set()
    queue = deque([(0, 0, [])])

    while queue:
        a, b, steps = queue.popleft()
        if a == x or b == x:
            return steps
        states = [
            (m, b, steps + ["FILL(1)"]),
            (a, n, steps + ["FILL(2)"]),
            (0, b, steps + ["DROP(1)"]),
            (a, 0, steps + ["DROP(2)"]),
            (min(a + b, m), 0 if a + b <= m else b - (m - a), steps + ["POUR(2,1)"]),
            (0 if a + b <= n else a - (n - b), min(a + b, n), steps + ["POUR(1,2)"])
        ]

        for state in states:
            if state[:2] not in visited:
                visited.add(state[:2])
                queue.append(state)
    return []

def can(m, n, x):
    return x % math.gcd(m, n) == 0
m,n,x=map(int,input().split())
if can(m,n,x)==False:
    print("impossible")
else:
    steps = bfs(m, n, x)
    print(len(steps))
    for step in steps:
        print(step)

```



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==
[![pkEaWe1.png](https://s21.ax1x.com/2024/05/06/pkEaWe1.png)](https://imgse.com/i/pkEaWe1)




### 05907: 二叉树的操作

http://cs101.openjudge.cn/practice/05907/



思路：
实际上我觉得交换子节点没那么难，但是一直调不好格式，看题解了

### 18250: 冰阔落 I

Disjoint set, http://cs101.openjudge.cn/practice/18250/
别的都很正常，就是判断哪些杯子有可乐一直调不好，看题解了
代码

```python
# 
class UnionFind:
    def __init__(self, n):
        self.parent = [i for i in range(n)]
        self.rank = [0] * n

    def find(self, x):
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])
        return self.parent[x]

    def union(self, x, y):
        root_x = self.find(x)
        root_y = self.find(y)
        if root_x != root_y:
            if self.rank[root_x] < self.rank[root_y]:
                root_x, root_y = root_y, root_x
            self.parent[root_y] = root_x
            if self.rank[root_x] == self.rank[root_y]:
                self.rank[root_x] += 1

    def connected(self, x, y):
        return self.find(x) == self.find(y)

n, m = map(int, input().split())
uf = UnionFind(n)
for i in range(m):
    x, y = map(int, input().split())
    if uf.connected(x, y):
        print("Yes")
    else:
        print("No")
        uf.union(x, y)

representatives = [uf.find(i) for i in range(n)]
unique_representatives = set(representatives)
print(len(unique_representatives))
print(" ".join(map(str, sorted(unique_representatives))))

```




### 05443: 兔子与樱花

http://cs101.openjudge.cn/practice/05443/

这题超出了理解范围，努力理解题解吧



代码运行截图 ==（AC代码截图，至少包含有"Accepted"）==





## 2. 学习总结和收获

==如果作业题目简单，有否额外练习题目，比如：OJ“2024spring每日选做”、CF、LeetCode、洛谷等网站题目。==
bfs的本质是走迷宫，dfs的本质是很长的蛇走迷宫（python走迷宫？）
如果能记住一个程序框架再往里面添加功能（如并查集），会简单很多




